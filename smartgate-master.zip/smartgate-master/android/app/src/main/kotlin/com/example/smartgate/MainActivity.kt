package com.example.smartgate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
