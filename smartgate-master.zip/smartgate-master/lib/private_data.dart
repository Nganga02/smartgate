// MQTT PARAMETERS
const mqttHost = "1138fa1dbe5d4f6cbdf0ca7a7562a3f1.s1.eu.hivemq.cloud";
const mqttPort = 8883;
const mqttUsername = 'Vincent';
const mqttPassword = '#Number3907';

// HTTPS PARAMETERS
// todo Firebase Database
const firebaseApiKey = "AIzaSyDyjPeJzMATf25BVYtWfWMZi_bH8QL-LEA";
const firebaseDbUrl = "https://elimu-96118-default-rtdb.firebaseio.com";
